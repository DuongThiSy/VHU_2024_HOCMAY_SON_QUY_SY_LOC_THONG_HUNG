
import torch.nn as nn
import sklearn
import matplotlib.pyplot as plt
import torch
from .LinearRegression import LinearRegressionModel

class TrainModel:

    def __init__(self, n_features, X_train, y_train, X_test, y_test):

        in_dimn = n_features  # input dimension its 12 in our case
        out_dimn = 1  # output dimension in our case 1

        # Creating the model in PyTorch

        model = LinearRegressionModel(in_dimn, out_dimn)  # Instantiating the model

        # #### Model Parameters: Lets see the parameters the model has and we can see that we have 12 eights input features which are the columns we provided and 1 output parameter which will store the numeric data we finally get.

        # ####  Compiling Model: Let us define the number of epochs and the learning rate we want for our model to train. As our data is continous so we need to define a loss function for numerical data, Mean Squared Error loss function has been taken in this work. Now the second step will be to use an Optimizer for finding the Global Minima, here Stocahstic Gradiant Descent has been used.
        #
        #


        self.train(model, X_train, y_train) #training model

        self.evaluate(model, X_test, y_test) #evaluating model on test data

    def evaluate(self, model, X_test, y_test):
        # Detaching the output from the computational graph and converting to numpy
        y_pred = model(X_test).detach().numpy()
        # #### Metric for visualizing Error: Let us see the r2 error, the best score is 1 and it can be negative or positive.
        from sklearn.metrics import r2_score,mean_squared_error
        print('---------o---------')
        print(f'R2 Score:{r2_score(y_test, y_pred):.4f}')
        print(f'Mean sqaured error:{mean_squared_error(y_test,y_pred):.4f}')
        # #### Let us see how the distribution of what model predicts and what it was given to the data
        # plt.scatter(y_test,y_pred, color="red")
        from matplotlib.pyplot import figure
        figure(figsize=(20, 6), dpi=80) #figure size
        plt.plot(y_test) #plotting y_test
        plt.xlabel("y_test") #labeling x axis
        plt.savefig("Output/y_test.png") #saving y_test image
        figure(figsize=(20, 6), dpi=80)
        plt.plot(y_pred, color="red") #plotting predicted y
        plt.xlabel("y_pred") #labeling x axis
        plt.savefig("Output/y_pred.png") #saving predicted y image

    def train(self, model, X_train, y_train):
        num_epochs = 600  # Training the model for large number of epochs to see better results
        learning_rate = 0.01
        criterion = nn.MSELoss()  # It's Linear Regression so use Mean Squared Error
        optimizer = torch.optim.SGD(model.parameters(), lr=learning_rate)  # Using SGD optimizer to find local minima
        # #### Visualizing the training process of the model by printing the epochs to see how the error is decreasing
        for epoch in range(num_epochs):
            y_pred = model(X_train)
            loss = criterion(y_pred, y_train)
            loss.backward() #backpropogation
            optimizer.step()
            optimizer.zero_grad()  # Lets clear the gradients
            if (epoch + 1) % 30 == 0:  # printing loss values on every 30 epochs to keep track
                print(f'epoch: {epoch + 1}, loss = {loss.item():.4f}')



